<?php
// test_script.php
$video_url = "https://www.bilibili.com/video/BV1xovCe7Ep4/?spm_id_from=333.788.recommend_more_video.0";
$format = "100047+30280";  // 选择的格式 ID
$command = "python3 /var/www/html/telegram_update/download_script.py \"$video_url\" \"$format\"";
exec($command, $output, $return_var);

echo "Command output:\n";
echo implode("\n", $output);
echo "\nReturn status: $return_var";
?>
